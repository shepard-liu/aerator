# 增氧机控制后台

## 登陆界面

<img src="https://tva1.sinaimg.cn/large/e6c9d24egy1h0wpjryiq7j20jq138gmj.jpg" alt="登陆界面" style="zoom:50%;" />

## 水质监控界面

<img src="https://tva1.sinaimg.cn/large/e6c9d24egy1h0wpl2not9j20jq138gnf.jpg" alt="水质监控界面" style="zoom:50%;" />

## 增氧机控制界面

<img src="https://tva1.sinaimg.cn/large/e6c9d24egy1h0wplfp2igj20jq138gnm.jpg" alt="增氧机控制界面" style="zoom:50%;" />

## 时间策略界面

<img src="https://tva1.sinaimg.cn/large/e6c9d24egy1h0wplruvh3j20jq138dhp.jpg" alt="时间策略界面" style="zoom:50%;" />